# Land_Registration_System_Using_Blockchain

Currently this project is not completed. We have completed planning and design & written some contracts and frontend for Minor Project 1.
